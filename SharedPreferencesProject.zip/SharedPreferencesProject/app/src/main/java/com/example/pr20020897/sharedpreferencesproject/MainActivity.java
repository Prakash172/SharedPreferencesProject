package com.example.pr20020897.sharedpreferencesproject;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    Button save, kill;
    EditText name, email, m_one, m_two,city;
    SharedPreferences sharedPreferences;
    public static final Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        save = findViewById(R.id.submit);
        kill = findViewById(R.id.kill);
        name = findViewById(R.id.name_input);
        email = findViewById(R.id.email_input);
        m_one = findViewById(R.id.m_one_input);
        m_two = findViewById(R.id.m_two_input);
        city = findViewById(R.id.city_input);


        sharedPreferences = getSharedPreferences("MyPrefe",0);
        setHints();
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(validation()){
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("name",name.getText().toString());
                editor.putString("email",email.getText().toString());
                editor.putString("num1",m_one.getText().toString());
                editor.putString("num2",m_two.getText().toString());
                editor.putString("city",city.getText().toString());
                editor.apply();
                    Toast.makeText(MainActivity.this, "Data saved successfully", Toast.LENGTH_SHORT).show();
                save.setEnabled(false);
                }else
                    Toast.makeText(MainActivity.this, "Please fill all the details properly", Toast.LENGTH_SHORT).show();

            }
        });

        kill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                save.setEnabled(true);
                finish();
            }
        });

    }

    public boolean stringContainsNumber( String s )
    {
        return Pattern.compile( "[0-9]" ).matcher( s ).find();
    }
    private boolean validation() {

        if (name.getText().toString().equals("")) return false;
            else if(stringContainsNumber(name.getText().toString())){
            Toast.makeText(this, "Name can't contain digit", Toast.LENGTH_SHORT).show();
            return  false;
            }
        if (m_two.getText().toString().equals("")) return false;
           else if (m_two.length() != 10) {
                Toast.makeText(this, "Please enter 10 digit number!", Toast.LENGTH_SHORT).show();
                return false;
            }

        if (m_one.getText().toString().equals("")) return false;
        else if (m_one.length() != 10) {
                Toast.makeText(this, "Please enter 10 digit number !", Toast.LENGTH_SHORT).show();
                return false;
            }
        if(email.getText().toString().equals("")) return false;
        else if(!validate(email.getText().toString())){
            Toast.makeText(this, "Enter correct email", Toast.LENGTH_SHORT).show();
            return false;
        }
        if(city.getText().toString().equals("")) return false;
        else if(stringContainsNumber(city.getText().toString())){
            Toast.makeText(this, "city name can't conatin number", Toast.LENGTH_SHORT).show();
        }

        return true;
    }


    public static boolean validate(String emailStr) {
        Matcher matcher = VALID_EMAIL_ADDRESS_REGEX .matcher(emailStr);
        return matcher.find();
    }
    private void setHints(){
        if(sharedPreferences.contains("name")){
            name.setText(sharedPreferences.getString("name",null));
            email.setText(sharedPreferences.getString("email",null));
            m_one.setText(sharedPreferences.getString("num1",null));
            m_two.setText(sharedPreferences.getString("num2",null));
            city.setText(sharedPreferences.getString("city",null));

        }

    }
}
